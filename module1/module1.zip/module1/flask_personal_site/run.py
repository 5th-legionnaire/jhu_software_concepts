'''Entry point for running the personal website with `python run.py`.'''

from board import create_app

app = create_app()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080, debug=True)
